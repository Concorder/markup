// If logged in:
// TODO: Insert a correct values here:

var user = {
	number: 38050576430155,
	isAuthorized: false,
	credits: 0,
	score: ,
}


// Cheching of login/profile window


// if there is a calc check

		if (user.isAuthorized == true) {
			document.querySelector('.login__alternate').style.display = 'none';
			calc_window.style.display = 'block'; } 